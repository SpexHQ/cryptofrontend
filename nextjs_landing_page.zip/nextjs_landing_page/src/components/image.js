import React from 'react';
import { Image as Img } from 'theme-ui';

export default function Image({ src, ...rest }) {
  return <h1>Image</h1>
}
