import React from 'react';
import { FaStar } from 'react-icons/fa';

const Rating = () => {
  return (
    <h1>Rating</h1>
  );
};

export default Rating;
