## Getting Started

Install the dependencies and run the development server

```bash
npm install
npm run dev
# or
yarn
yarn dev
```